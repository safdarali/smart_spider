package file_crawlr;

import java.io.*;
import java.util.*;


public class class_main {
	File file_fold;
	File[] file_lst;	
	String parentDirectory;

	
	
	public static ArrayList<String> size_of_file;
	public static ArrayList<String> file_modification;
	public static ArrayList<String> contnt;
	public static ArrayList<String> path_file_i;
	public static ArrayList<String> file_ownrshp;
	
	public class_main(){
		this.parentDirectory = "/home/idea/Desktop/directory";
		file_fold = new File(this.parentDirectory);
		file_lst = file_fold.listFiles();
		contnt = new ArrayList<String>();
		path_file_i = new ArrayList<String>();
		size_of_file = new ArrayList<String>();
		file_modification = new ArrayList<String>();
		file_ownrshp = new ArrayList<String>();
		
	}
	public String parent_get(){
		return this.parentDirectory;
	}
	public ArrayList<String> obtainF_Content(){
		return class_main.contnt;
	}
	public ArrayList<String> obtainF_Path(){
		return class_main.path_file_i;
	}
	public ArrayList<String> obtainF_size(){
		return class_main.size_of_file;
	}
	public ArrayList<String> getlasModified(){
		return class_main.file_modification;
	}
	
	
	@SuppressWarnings("resource")
	public static void main(String[] args) throws InterruptedException {
		
		class_main mainCrawl = new class_main();
		
		Thread allThreadInde = new Thread(new file_index());
		allThreadInde.setDaemon(true);
		allThreadInde.start();
		
		Thread thread_of_crawler = new Thread(new file_Crawler(mainCrawl.parentDirectory));
		thread_of_crawler.start();
		thread_of_crawler.join();
		
		System.out.println("string inter to search that string?");
		Scanner inp = new Scanner(System.in);
		String cont_search = inp.next();
		
		Thread thread_of_search = new Thread(new file_search( cont_search));
		thread_of_search.start();
		
		
		
	}

}
