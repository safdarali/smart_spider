package file_crawlr;

import java.io.*;
import java.nio.*;
import java.text.SimpleDateFormat;
import java.util.*;


public class file_Crawler implements Runnable {
	
	
	public static ArrayList<String> file_modification;
	public static ArrayList<String> contnt;
	public static ArrayList<String> path_file_i;
	public static ArrayList<String> size_of_file;
	public static ArrayList<String> file_ownrshp;
	public String parentDirectory;
	
//constructor
	public file_Crawler(String temp){
		file_Crawler.file_ownrshp = new ArrayList<String>();
		file_Crawler.path_file_i = new ArrayList<String>();
		parentDirectory = temp;
		file_Crawler.contnt = new ArrayList<String>();
		file_Crawler.file_modification = new ArrayList<String>();
		file_Crawler.size_of_file = new ArrayList<String>();
	}
	
	public void run() {
		crawl(this.parentDirectory);
		
	}	
	

	public String file_parsr(File fle){
		List<String> tmp_line = null;
		String str_con = "";
		try {
			tmp_line = Files.readAllLines(Paths.get(fle.getAbsolutePath()),StandardCharsets.UTF_8);
		} catch (IOException e) {}
		
		
		for(int i=0 ; i<tmp_line.size(); i++ ){
			str_con += (String) tmp_line.get(i);
		}
		return str_con;
	}

	public void crawl( String tempPath ) {

		File parentDirectory = new File( tempPath );
		File[] fileLst = parentDirectory.listFiles();

		if (fileLst == null) return;

		for ( File fle : fileLst ) {
			if ( fle.isDirectory() ) {
				try{
					crawl( fle.getAbsolutePath() );
				}catch(Exception e){}
			}
			else {
				SimpleDateFormat smpl_d = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				
				if(fle.getName().contains(".txt")){
					file_Crawler.contnt.add(file_parsr(fle));
					file_Crawler.size_of_file.add(""+fle.length()+" Bytes");
					file_Crawler.file_modification.add(""+smpl_d.format(fle.lastModified()));
					
					if(fle.canRead())
						if(fle.canRead())
							file_Crawler.file_ownrshp.add("Read : True & Write : True");
						else
							file_Crawler.file_ownrshp.add("Read : True & Write : False");
					else
						if(fle.canRead())
							file_Crawler.file_ownrshp.add("Read : False & Write : True");
						else
							file_Crawler.file_ownrshp.add("Read : False & Write : False");
					
					file_Crawler.path_file_i.add(fle.getAbsolutePath());
				}
			}
		}
	}
	
}

