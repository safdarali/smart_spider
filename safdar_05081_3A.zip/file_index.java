package file_crawlr;
import java.util.*;

public class file_index implements Runnable {

	private ArrayList<String> file_ownrshp;
	private ArrayList<String> size_of_file;
	private ArrayList<String> contnt;
	private ArrayList<String> path_file_i;
	private ArrayList<String> file_modification;
	
	//constructor
	public file_index(){
		this.contnt = new ArrayList<String>();
		this.file_modification = new ArrayList<String>();
		this.file_ownrshp = new ArrayList<String>();
		this.path_file_i = new ArrayList<String>();
		this.size_of_file = new ArrayList<String>();
	}
	
	public void run(){
		
		while(true){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if(file_Crawler.contnt.size()>0){
				
				for(int i=0 ; i<file_Crawler.contnt.size() ; i++ ){
					
					this.size_of_file.add(file_Crawler.size_of_file.get(i));
					this.file_modification.add(file_Crawler.file_modification.get(i));
					this.file_ownrshp.add(file_Crawler.file_ownrshp.get(i));
					this.contnt.add(file_Crawler.contnt.get(i));
					this.path_file_i.add(file_Crawler.path_file_i.get(i));
					
					
				}
				file_Crawler.contnt.clear();
				file_Crawler.file_modification.clear();
				file_Crawler.file_ownrshp.clear();
				file_Crawler.path_file_i.clear();
				file_Crawler.size_of_file.clear();
				
						
				for(int i=0 ; i<this.contnt.size() ; i++){
					class_main.contnt.add(this.contnt.get(i));
					class_main.file_modification.add(this.file_modification.get(i));
					class_main.file_ownrshp.add(this.file_ownrshp.get(i));
					class_main.path_file_i.add(this.path_file_i.get(i));
					class_main.size_of_file.add(this.size_of_file.get(i));
					
				}
				
				
				this.size_of_file.clear();
				this.file_modification.clear();
				this.file_ownrshp.clear();
				this.contnt.clear();
				this.path_file_i.clear();
				
			}
		}
		
	}

}
