package file_crawlr;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class file_search implements Runnable {
            private static Pattern pattern;
	    private static Matcher matcher;

	public String file_search_t;
	
	public file_search(String temp){
		this.file_search_t = temp;
	}

	public void file_search_t(String temp){
	    private static final String REGEX = "";
	    private static final String INPUT = temp;
	  	
	for (int i=0 ; i<class_main.path_file_i.size() ; i++){
			if(class_main.path_file_i.get(i).contains(temp) || class_main.contnt.get(i).contains(temp))
				REGEX = class_main.path_file_i.get(i);
				pattern = Pattern.compile(REGEX);
       				matcher = pattern.matcher(INPUT);

       				System.out.println("Current REGEX is: "+REGEX);
       				System.out.println("Current INPUT is: "+INPUT);

      				 System.out.println("lookingAt(): "+matcher.lookingAt());
     				  System.out.println("matches(): "+matcher.matches());
				REGEX =class_main.path_file_i.get(i);
				pattern = Pattern.compile(REGEX);
       				matcher = pattern.matcher(INPUT);

       				System.out.println("Current REGEX is: "+REGEX);
       				System.out.println("Current INPUT is: "+INPUT);

      				 System.out.println("lookingAt(): "+matcher.lookingAt());
     				  System.out.println("matches(): "+matcher.matches());


				REGEX = class_main.file_modification.get(i);
				pattern = Pattern.compile(REGEX);
       				matcher = pattern.matcher(INPUT);

       				System.out.println("Current REGEX is: "+REGEX);
       				System.out.println("Current INPUT is: "+INPUT);

      				 System.out.println("lookingAt(): "+matcher.lookingAt());
     				  System.out.println("matches(): "+matcher.matches());
				
			REGEX = class_main.file_ownrshp.get(i);				
				pattern = Pattern.compile(REGEX);
       				matcher = pattern.matcher(INPUT);

       				System.out.println("Current REGEX is: "+REGEX);
       				System.out.println("Current INPUT is: "+INPUT);

      				 System.out.println("lookingAt(): "+matcher.lookingAt());
     				  System.out.println("matches(): "+matcher.matches());

				REGEX = class_main.size_of_file.get(i);
				pattern = Pattern.compile(REGEX);
       				matcher = pattern.matcher(INPUT);

       				System.out.println("Current REGEX is: "+REGEX);
       				System.out.println("Current INPUT is: "+INPUT);

      				 System.out.println("lookingAt(): "+matcher.lookingAt());
     				  System.out.println("matches(): "+matcher.matches());

				System.out.println();
		}
	
	

	}
	
	public void run() {
		file_search_t(this.file_search_t);
	}	
}
