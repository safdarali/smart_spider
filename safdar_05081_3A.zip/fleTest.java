package file_crawlr;

import static org.junit.Assert.*;

import java.io.*;

import org.junit.Test;

public class fleTest {

	@Test
	public void untTest() {

		class_main mainCrawl = new class_main();
		assertEquals("/home/idea/Desktop/directory", mainCrawl.parentDirectory);
		class_main mainCrawl = new class_main();
		File f = new File(mainCrawl.parentDirectory);
		
		if(!f.exists()){
			fail("File not exist");
		}	
	}
	
}
